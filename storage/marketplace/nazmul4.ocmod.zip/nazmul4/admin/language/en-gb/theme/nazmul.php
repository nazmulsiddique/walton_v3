<?php
// Heading
$_['heading_title'] = 'Nazmul Theme';

// Text
$_['text_extension'] = 'Extensions';
$_['text_success'] = 'Success: You have modified the Nazmul theme!';
$_['text_edit'] = 'Edit Nazmul Theme';

// Entry
$_['entry_status'] = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify the Nazmul theme!';
