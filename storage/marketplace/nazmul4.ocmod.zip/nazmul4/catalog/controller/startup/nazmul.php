<?php
namespace Opencart\Catalog\Controller\Extension\nazmul4\Startup;

class Nazmul extends \Opencart\System\Engine\Controller
{
    public function index(): void
    {
        if ($this->config->get('theme_nazmul_status')) {
            $this->event->register('view/*/before', new \Opencart\System\Engine\Action('extension/nazmul4/startup/nazmul|event'));
        }
    }

    public function event(string &$route, array &$args, mixed &$output): void
    {
        $override = [
            'common/header',
        ];

        if (in_array($route, $override)) {
            $route = 'extension/nazmul4/' . $route;
        }
    }
}
