# WaltonBD Full Theme Clone Helper for OpenCart 4.1.x

This package contains the WaltonBD theme extension and a helper script to clone
OpenCart's built-in `default` theme (Twig, CSS, JS, images) into:

`catalog/view/theme/waltonbd/`

## Steps

1. Upload and install `waltonbd_full_clone.ocmod.zip` from Admin > Extensions > Installer.
2. Extract `copy_default_theme.php` to your OpenCart root directory.
3. Open in browser:
   `https://yourdomain.com/copy_default_theme.php`
4. Delete `copy_default_theme.php` after success.
5. In Admin > Extensions > Extensions > Themes, install WaltonBD Theme.
6. In System > Settings > Edit Store, choose `WaltonBD`.

## Notes

- The helper script copies every file from `catalog/view/theme/default`.
- Existing `catalog/view/theme/waltonbd` files will be overwritten.
- Delete the script after use for security.
