<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$source = __DIR__ . '/catalog/view/theme/default';
$destination = __DIR__ . '/catalog/view/theme/waltonbd';

function copyRecursive($src, $dst) {
    if (!is_dir($src)) {
        throw new Exception('Source theme not found: ' . $src);
    }

    if (!is_dir($dst)) {
        mkdir($dst, 0755, true);
    }

    $items = scandir($src);

    foreach ($items as $item) {
        if ($item === '.' || $item === '..') continue;

        $srcPath = $src . DIRECTORY_SEPARATOR . $item;
        $dstPath = $dst . DIRECTORY_SEPARATOR . $item;

        if (is_dir($srcPath)) {
            copyRecursive($srcPath, $dstPath);
        } else {
            copy($srcPath, $dstPath);
        }
    }
}

try {
    copyRecursive($source, $destination);
    echo '<h2>Success!</h2>';
    echo '<p>Default theme has been copied to <strong>catalog/view/theme/waltonbd</strong>.</p>';
    echo '<p>Please delete this file now: <strong>copy_default_theme.php</strong></p>';
} catch (Exception $e) {
    echo '<h2>Error</h2><pre>' . htmlspecialchars($e->getMessage()) . '</pre>';
}
