<?php
namespace Opencart\Admin\Controller\Extension\Waltonbd\Theme;

class Waltonbd extends \Opencart\System\Engine\Controller {
    public function index(): void {
        $this->load->language('extension/waltonbd/theme/waltonbd');
        $this->document->setTitle($this->language->get('heading_title'));

        $data['heading_title'] = $this->language->get('heading_title');
        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput(
            $this->load->view('extension/waltonbd/theme/waltonbd', $data)
        );
    }

    public function save(): void {
        $this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode([
            'success' => 'Settings saved successfully.'
        ]));
    }
}
