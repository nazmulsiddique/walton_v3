<?php
$_['heading_title'] = 'WaltonBD Theme';
