<?php
// Heading
$_['heading_title'] = 'Walton Group Theme';

// Text
$_['text_extension'] = 'Extensions';
$_['text_success'] = 'Success: You have modified the Walton Group theme!';
$_['text_edit'] = 'Edit Walton Group Theme';

// Entry
$_['entry_status'] = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify the Walton Group theme!';
