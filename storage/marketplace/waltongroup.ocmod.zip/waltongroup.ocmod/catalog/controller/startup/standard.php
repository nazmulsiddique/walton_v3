<?php
namespace Opencart\Catalog\Controller\Extension\waltongroup\Startup;

class WaltonGroup extends \Opencart\System\Engine\Controller
{
    public function index(): void
    {
        if ($this->config->get('theme_waltongroup_status')) {
            $this->event->register('view/*/before', new \Opencart\System\Engine\Action('extension/waltongroup/startup/waltongroup|event'));
        }
    }

    public function event(string &$route, array &$args, mixed &$output): void
    {
        $override = [
            'common/header',
        ];

        if (in_array($route, $override)) {
            $route = 'extension/waltongroup/' . $route;
        }
    }
}
